package com.hotelapp.model;

public class Hotel {
	String hname;
	String hcity;
	Integer hId;
	String cuisine;
	
	public Hotel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Hotel(String hname, String hcity, Integer hId, String cuisine) {
		super();
		this.hname = hname;
		this.hcity = hcity;
		this.hId = hId;
		this.cuisine = cuisine;
	}

	public String getHname() {
		return hname;
	}

	public void setHname(String hname) {
		this.hname = hname;
	}

	public String getHcity() {
		return hcity;
	}

	public void setHcity(String hcity) {
		this.hcity = hcity;
	}

	public Integer gethId() {
		return hId;
	}

	public void sethId(Integer hId) {
		this.hId = hId;
	}

	public String getCuisine() {
		return cuisine;
	}

	public void setCuisine(String cuisine) {
		this.cuisine = cuisine;
	}

	@Override
	public String toString() {
		return "Hotel [hname=" + hname + ", hcity=" + hcity + ", hId=" + hId + ", cuisine=" + cuisine + "]";
	}
	
	

}


