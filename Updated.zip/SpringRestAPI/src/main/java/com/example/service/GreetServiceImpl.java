package com.example.service;

import org.springframework.stereotype.Service;

@Service

public class GreetServiceImpl implements GreetService{

	@Override
	public String showMessage() {
		return "Have a great day";
	}

	@Override
	public String welcomeUser(String name) {
		return "welcome "+name.toUpperCase();
	}

	@Override
	public String printName(String name) {
		return "Hello "+name.toLowerCase();
	}

}
