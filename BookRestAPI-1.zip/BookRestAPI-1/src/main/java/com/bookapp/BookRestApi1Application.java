package com.bookapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookRestApi1Application {

	public static void main(String[] args) {
		SpringApplication.run(BookRestApi1Application.class, args);
	}

}
